# Simple-Calculator
it is a calculator designed in python with PyQ5
it allows the expression calculation all this thanks to the Polish notation
before using this please make sure that you have install PyQt5 like this 
pip install PyQt5
